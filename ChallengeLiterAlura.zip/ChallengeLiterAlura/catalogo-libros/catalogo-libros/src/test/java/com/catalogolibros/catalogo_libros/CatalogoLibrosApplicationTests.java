package com.catalogolibros.catalogo_libros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CatalogoLibrosApplicationTests {

	@Test
	void contextLoads() {
	}

}
