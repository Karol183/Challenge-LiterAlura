Se agrega estructura de spring para challenguer LiterAlura
